from pathlib import Path
import re
root=Path.cwd(); index=root/'index.html'; content=root/'functions/api/_content.js'
if not index.exists() or not content.exists(): raise SystemExit('Ejecuta este script en la raíz del repositorio calendario-adviento-pippo-2026')
html=index.read_text(); js=content.read_text()
for f,s in [(index,html),(content,js)]:
 backup=f.with_suffix(f.suffix+'.respaldo');
 if not backup.exists():backup.write_text(s)
intro='¡Bienvenidos al Calendario de Adviento del Club de Pippo! Cada día de diciembre podrás regresar para descubrir un cupón promocional o una sorpresa especial de Navidad que hemos preparado para ti. Cuando se abra una nueva casilla, las de los días anteriores permanecerán abiertas para que puedas volver a disfrutar de tus regalos. ¡Esperamos que disfrutes todas estas sorpresas! ¡Comenzamos el 1 de diciembre!'
html=re.sub(r'<p class="hint">.*?</p>', '<p class="hint">'+intro+'</p>',html,count=1,flags=re.S)
html=html.replace('dialog .close{', 'dialog .close{')
html=html.replace('</style>', '.gift-images{display:grid;gap:10px;margin:12px 0}.gift-images img{width:100%;height:auto;display:block;border-radius:12px;background:white}.gift-images a{display:block;color:white;text-align:center;font-weight:700}.gift-images img{max-height:70vh;object-fit:contain}.hint{line-height:1.6;background:#163b5a;border-radius:12px;padding:15px!important}</style>')
html=html.replace('<p id="modalBody"></p>', '<p id="modalBody"></p><div id="giftImages" class="gift-images"></div>')
old="document.getElementById('modalTerms').textContent=d.terms||'';"
new="""document.getElementById('modalTerms').textContent=d.terms||'';const gallery=document.getElementById('giftImages');gallery.replaceChildren();const files=Array.isArray(d.files)?d.files:(d.file?[d.file]:[]);if(d.published){for(const url of files){if(!/^\\/assets\\/[a-z0-9_./-]+\\.(png|jpg|jpeg|webp)$/i.test(url))continue;const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';a.download='club-pippo-dia-'+d.day;const img=document.createElement('img');img.src=url;img.alt='Regalo del día '+d.day;a.append(img);const label=document.createElement('span');label.textContent='Abrir imagen para guardar';a.append(label);gallery.append(a)}}"""
if 'giftImages' not in html.split('<script>')[-1]:
 if old not in html:raise SystemExit('No se pudo ubicar renderDay; no se modificó el archivo')
 html=html.replace(old,new)
index.write_text(html)
# Actualizar únicamente las entradas de días con material visual confirmado
updates={
2:('Descuento para hermanos','$100 de descuento por cada hermano, por niño.','Del 1 al 31 de diciembre de 2026. Reutilizable: un cupón por visita. No acumulable con otras promociones.',['/assets/regalos/dia02_hermanos.png']),
3:('Carta para Santa Claus','Descarga tu carta para Santa Claus y escribe tus deseos.','Material gratuito para imprimir.',['/assets/regalos/dia03_carta_santa.png']),
5:('Sticker navideño del Club de Pippo','Sticker navideño del Club de Pippo.','Imagen digital para guardar o imprimir.',['/assets/regalos/dia05_sticker.png']),
6:('Certificado de Ayudante Navideño','Completa tu misión navideña y descarga tu certificado.','Material gratuito para imprimir.',['/assets/regalos/dia06_certificado.png']),
8:('Dibujos para colorear','Tres dibujos navideños de Pippo, Rumi y Peluche para colorear.','Tres láminas gratuitas para imprimir.',['/assets/regalos/dia08_colorear_1.png','/assets/regalos/dia08_colorear_2.png','/assets/regalos/dia08_colorear_3.png']),
9:('Sellador dental a $270','Sellador dental a $270 por diente.','Del 1 al 31 de diciembre de 2026. Sujeto a valoración e indicación clínica. Reutilizable: un cupón por visita. No acumulable con otras promociones.',['/assets/regalos/dia09_sellador.png']),
11:('Sticker navideño de Pippo','Segundo sticker navideño del Club de Pippo.','Imagen digital para guardar o imprimir.',['/assets/regalos/dia11_sticker.png']),
12:('Diploma navideño','Diploma Guardián de Sonrisas para personalizar.','Material gratuito para imprimir.',['/assets/regalos/dia12_diploma.png']),
23:('Cupón de Annie · Partera en Ruta','$200 de descuento en acompañamiento con Annie Arenas, Partera en Ruta.','Válido durante diciembre de 2026. Confirma con Annie los servicios aplicables, disponibilidad y condiciones antes de canjear.',['/assets/regalos/dia23_annie.png'])}
lines=js.splitlines(keepends=True); entries=[i for i,l in enumerate(lines) if l.lstrip().startswith('{title:')]
if len(entries)!=24:raise SystemExit('Se esperaban 24 casillas; encontrado '+str(len(entries)))
for day,(title,body,terms,files) in updates.items():
 def quote(s):return "'"+s.replace('\\','\\\\').replace("'","\\'")+"'"
 line=' {title:'+quote(title)+',published:true,body:'+quote(body)+',terms:'+quote(terms)+',file:'+quote(files[0])+',files:['+','.join(map(quote,files))+']},\n'
 lines[entries[day-1]]=line
content.write_text(''.join(lines))
print('Actualizados index.html y functions/api/_content.js; respaldos .respaldo creados. Imágenes instaladas en assets/regalos.')
